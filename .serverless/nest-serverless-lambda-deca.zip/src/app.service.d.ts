export declare class AppService {
    getHello(): {
        response: string;
    };
    solveQuestionOne(answer: string): {
        passed: boolean;
        nextQuestion: string | undefined;
    };
    solveQuestionTwo(answer: string, answerOne: string): {
        passed: boolean;
        nextQuestion: string | undefined;
    };
    solveQuestionThree(answer: string, answerOne: string, answerTwo: string): {
        passed: boolean;
        url: string | undefined;
    };
}
