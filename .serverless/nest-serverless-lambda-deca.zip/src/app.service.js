"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AppService = void 0;
const common_1 = require("@nestjs/common");
let AppService = class AppService {
    getHello() {
        return { response: 'Hello World!' };
    }
    solveQuestionOne(answer) {
        if (answer == 'your answer here')
            return {
                passed: true,
                nextQuestion: 'To finish the full circle, answer the following question:\nWhere are we connected?',
            };
        return { passed: false, nextQuestion: undefined };
    }
    solveQuestionTwo(answer, answerOne) {
        if (this.solveQuestionOne(answerOne).passed)
            if (answer == 'chaos')
                return {
                    passed: true,
                    nextQuestion: '👌❎🔟🎨on 🟦🕊, ⬆️🖼. 👈☹️🆔',
                };
        return { passed: false, nextQuestion: undefined };
    }
    solveQuestionThree(answer, answerOne, answerTwo) {
        console.log(answerOne, answerTwo);
        if (this.solveQuestionTwo(answerTwo, answerOne).passed)
            if (answer == '4047')
                return {
                    passed: true,
                    url: 'https://a57a880c-a90d-4a78-b2d8-6efaecff4a0b.vercel.app/f24760a5-ec25-4a66-844e-1a947201493a',
                };
        return { passed: false, url: undefined };
    }
};
AppService = __decorate([
    (0, common_1.Injectable)()
], AppService);
exports.AppService = AppService;
//# sourceMappingURL=app.service.js.map