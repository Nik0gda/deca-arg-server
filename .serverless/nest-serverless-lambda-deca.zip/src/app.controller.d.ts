import { AppService } from './app.service';
export declare class AppController {
    private readonly appService;
    constructor(appService: AppService);
    getHello(): {
        response: string;
    };
    solveQuestionOne(answer: string): {
        passed: boolean;
        nextQuestion: string | undefined;
    };
    solveQuestioTwo(answer: string, answerOne: string | undefined): {
        passed: boolean;
        nextQuestion: string | undefined;
    };
    solveQuestioThree(answer: string, answerOne: string | undefined, answerTwo: string | undefined): {
        passed: boolean;
        url: string | undefined;
    };
}
